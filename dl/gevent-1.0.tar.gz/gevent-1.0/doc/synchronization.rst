Synchronization primitives
--------------------------

.. toctree::

   gevent.event
   gevent.queue
   gevent.lock

